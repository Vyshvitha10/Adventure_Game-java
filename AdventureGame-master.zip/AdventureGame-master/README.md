# Adventure Game

## a text based adventure game.

*Used for Java OOP in this project: inheritance, encapsulation, polymorphism, abstraction, interface etc.*
<br>
*Created uml class diagram and encoded accordingly.*

![Adventure Game](/UML/class-diagram.jpg)