public class Vampire extends Monster {
    public Vampire() {
        super(2, "Vampir", 4, 14, 7);
    }
}
