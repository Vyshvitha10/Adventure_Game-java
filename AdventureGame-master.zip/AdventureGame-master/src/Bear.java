public class Bear extends Monster {
    public Bear() {
        super(3, "Ayı", 7, 20, 12);
    }
}
