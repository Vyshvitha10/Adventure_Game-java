public class Chevalier extends Character {
    public Chevalier() {
        super(3, "Şövalye", 8, 24, 5);
    }
}
