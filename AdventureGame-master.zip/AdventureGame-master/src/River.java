public class River extends BattleLocation {
    public River(Player player) {
        super(player, "Nehir", new Bear(), "Su", 2);
    }
}
