public class Zombie extends Monster {
    public Zombie() {
        super(1, "Zombi", 3, 10, 4);
    }
}
