public class Forest extends BattleLocation {
    public Forest(Player player) {
        super(player, "Orman", new Vampire(), "Odun", 3);
    }
}
