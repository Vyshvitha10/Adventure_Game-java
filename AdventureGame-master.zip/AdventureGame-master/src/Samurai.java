public class Samurai extends Character {
    public Samurai() {
        super(1, "Samuray", 5, 21, 15);
    }
}
